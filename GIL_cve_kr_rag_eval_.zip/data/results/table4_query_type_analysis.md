| Query Type            | Method          |   Hit@1 |   Recall@5 |   MRR@10 |   Field Accuracy |   Citation Accuracy |
|:----------------------|:----------------|--------:|-----------:|---------:|-----------------:|--------------------:|
| vulnerability_summary | bm25            |    1    |       1    |   1      |           0.9133 |                0.92 |
| vulnerability_summary | dense           |    0.48 |       0.7  |   0.5686 |           0.6783 |                0.68 |
| vulnerability_summary | hybrid          |    1    |       1    |   1      |           0.9567 |                0.97 |
| vulnerability_summary | hybrid_reranker |    1    |       1    |   1      |           0.9517 |                0.97 |
| affected_product      | bm25            |    1    |       1    |   1      |           0.9633 |                0.97 |
| affected_product      | dense           |    0.37 |       0.68 |   0.4879 |           0.67   |                0.67 |
| affected_product      | hybrid          |    1    |       1    |   1      |           0.9417 |                0.94 |
| affected_product      | hybrid_reranker |    0.99 |       1    |   0.995  |           0.9767 |                0.98 |
| attack_condition      | bm25            |    1    |       1    |   1      |           0.9733 |                0.99 |
| attack_condition      | dense           |    0.28 |       0.48 |   0.3715 |           0.51   |                0.48 |
| attack_condition      | hybrid          |    1    |       1    |   1      |           0.9967 |                1    |
| attack_condition      | hybrid_reranker |    0.98 |       1    |   0.9883 |           0.9917 |                1    |
| severity_reason       | bm25            |    1    |       1    |   1      |           0.7383 |                0.75 |
| severity_reason       | dense           |    0.37 |       0.63 |   0.4792 |           0.5717 |                0.56 |
| severity_reason       | hybrid          |    0.99 |       1    |   0.995  |           0.8417 |                0.84 |
| severity_reason       | hybrid_reranker |    1    |       1    |   1      |           0.875  |                0.88 |
| mitigation            | bm25            |    1    |       1    |   1      |           0.9717 |                0.98 |
| mitigation            | dense           |    0.5  |       0.69 |   0.5864 |           0.6783 |                0.68 |
| mitigation            | hybrid          |    1    |       1    |   1      |           0.945  |                0.96 |
| mitigation            | hybrid_reranker |    1    |       1    |   1      |           0.9417 |                0.95 |
